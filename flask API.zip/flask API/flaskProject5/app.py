from flask import Flask

app = Flask(__name__) # I am creating flask application


@app.route('/') # decorator
def hello_world():  # put application's code here
    return 'Hello World!'


if __name__ == '__main__': # flask method
    app.run() # flask application
