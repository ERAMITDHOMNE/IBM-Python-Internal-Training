from fastapi import FastAPI

from typing import Optional
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def root():
    return {"message": "Hello World"}